CREATE PROCEDURE testprocedure(OUT names VARCHAR(50))
  BEGIN
    SELECT username FROM user;
  END;
